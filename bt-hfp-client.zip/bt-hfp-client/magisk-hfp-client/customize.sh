#!/system/bin/sh
if [ "$API" -lt 33 ]; then
  abort "! This module requires Android 13 (API 33) or newer"
fi

ui_print "- Mi 11i Bluetooth HFP Client"
ui_print "- Installing RRO overlay + BtHeadsetCompanion priv-app"

set_perm_recursive $MODPATH/system/priv-app/BtHeadsetCompanion 0 0 0755 0644
set_perm_recursive $MODPATH/system/product/overlay 0 0 0755 0644
set_perm_recursive $MODPATH/system/etc/permissions 0 0 0755 0644

ui_print "- Reboot, then open the BT Headset app and pair your phone"
