#!/system/bin/sh
# Wait for boot, then auto-grant runtime permissions and start the service.
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
sleep 10

# Debug log for audio troubleshooting (remove later): /sdcard/Download/hfp_log.txt
LOG=/sdcard/Download/hfp_log.txt
rm -f "$LOG" "$LOG.1" 2>/dev/null
nohup logcat -v threadtime -f "$LOG" -r 3072 -n 2 >/dev/null 2>&1 &
sleep 3
chmod 666 "$LOG" 2>/dev/null

PKG=com.axrana.btheadset
for p in BLUETOOTH_CONNECT RECORD_AUDIO POST_NOTIFICATIONS; do
  pm grant $PKG android.permission.$p 2>/dev/null
done
cmd appops set $PKG SYSTEM_ALERT_WINDOW allow 2>/dev/null
am start-foreground-service -n $PKG/.HfpClientService 2>/dev/null
