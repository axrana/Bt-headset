#!/system/bin/sh
# Wait for boot, then keep a copy of the Bluetooth packet log in Downloads (for troubleshooting).
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
sleep 15

OUT=/data/media/0/Download
SRC=/data/misc/bluetooth/logs/btsnoop_hci.log

(
  while true; do
    if [ -f "$SRC" ]; then
      cp "$SRC" "$OUT/hfp_snoop.log" 2>/dev/null
      chown 1023:1023 "$OUT/hfp_snoop.log" 2>/dev/null
      chmod 666 "$OUT/hfp_snoop.log" 2>/dev/null
      chcon u:object_r:media_rw_data_file:s0 "$OUT/hfp_snoop.log" 2>/dev/null
    fi
    sleep 10
  done
) >/dev/null 2>&1 &
