# Mi 11i Bluetooth HFP Client

Magisk module + companion app that make a rooted Android 13 phone act as a Bluetooth
Hands-Free (HFP-HF) client for calls from another phone.

1. Push this repo to GitHub (branch `main`).
2. Wait for the **Build Magisk HFP Client** workflow; download `Magisk-Mi11i-HFP-Client.zip`.
3. Flash in Magisk, reboot.
4. Pair the other phone in Bluetooth settings, then open **BT Headset** and tap *Connect to paired phone*.
