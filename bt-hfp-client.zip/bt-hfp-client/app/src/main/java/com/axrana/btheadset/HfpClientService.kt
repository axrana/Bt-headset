package com.axrana.btheadset

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.Log
import java.util.concurrent.CopyOnWriteArrayList

class HfpClientService : Service() {

    interface Listener {
        fun onHfpChanged()
    }

    companion object {
        private const val TAG = "HfpClientService"
        private const val PROFILE_HEADSET_CLIENT = 16

        const val ACTION_CONN = "android.bluetooth.headsetclient.profile.action.CONNECTION_STATE_CHANGED"
        const val ACTION_CALL = "android.bluetooth.headsetclient.profile.action.AG_CALL_CHANGED"
        const val ACTION_CALL_ALT = "android.bluetooth.headsetclient.profile.action.CALL_CHANGED"
        const val ACTION_AUDIO = "android.bluetooth.headsetclient.profile.action.AUDIO_STATE_CHANGED"
        const val ACTION_AG_EVENT = "android.bluetooth.headsetclient.profile.action.AG_EVENT"

        const val CMD_ANSWER = "com.axrana.btheadset.ANSWER"
        const val CMD_REJECT = "com.axrana.btheadset.REJECT"
        const val CMD_END = "com.axrana.btheadset.END"

        private const val CH_ONGOING = "hfp_ongoing"
        private const val CH_CALL = "hfp_call"
        private const val NOTIF_ONGOING = 1
        private const val NOTIF_CALL = 2

        @Volatile
        var instance: HfpClientService? = null
        val listeners = CopyOnWriteArrayList<Listener>()

        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, HfpClientService::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var audio: AudioManager
    private lateinit var nm: NotificationManager

    @Volatile var client: HfpClientProxy? = null
        private set
    private var proxyObj: BluetoothProfile? = null

    @Volatile var device: BluetoothDevice? = null
        private set
    @Volatile var calls: List<CallInfo> = emptyList()
        private set
    @Volatile var speakerOn = false
        private set
    @Volatile var muted = false
        private set

    private var audioActive = false
    private var lastAudioAttempt = 0L
    private var ringtone: Ringtone? = null

    private val prefs by lazy { getSharedPreferences("cfg", Context.MODE_PRIVATE) }
    private val logLines = java.util.ArrayDeque<String>()

    fun audioMode(): Int = prefs.getInt("audio_mode", 0)
    fun audioModeName(): String = when (audioMode()) {
        0 -> "0 (stack handles audio)"
        1 -> "1 (+ connectAudio)"
        else -> "2 (+ AudioManager routing)"
    }
    fun cycleAudioMode() {
        prefs.edit().putInt("audio_mode", (audioMode() + 1) % 3).apply()
        teardownAudio()
        notifyChanged()
    }

    @Synchronized fun log(msg: String) {
        logLines.addFirst(msg)
        while (logLines.size > 14) logLines.removeLast()
    }
    @Synchronized fun logText(): String = logLines.joinToString("\n")

    private val profileListener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
            if (profile != PROFILE_HEADSET_CLIENT) return
            handler.post {
                proxyObj = proxy
                client = HfpClientProxy(proxy)
                Log.i(TAG, "HEADSET_CLIENT proxy connected")
                refresh()
            }
        }

        override fun onServiceDisconnected(profile: Int) {
            if (profile != PROFILE_HEADSET_CLIENT) return
            handler.post {
                client = null
                proxyObj = null
                refresh()
            }
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val st = intent.getIntExtra("android.bluetooth.profile.extra.STATE", -1)
            val pv = intent.getIntExtra("android.bluetooth.profile.extra.PREVIOUS_STATE", -1)
            log("${intent.action?.substringAfterLast('.')} state=$st prev=$pv")
            handler.post { refresh() }
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        audio = getSystemService(AudioManager::class.java)
        nm = getSystemService(NotificationManager::class.java)
        createChannels()
        startForeground(
            NOTIF_ONGOING,
            ongoingNotification("Waiting for phone"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
        )

        val filter = IntentFilter().apply {
            addAction(ACTION_CONN)
            addAction(ACTION_CALL)
            addAction(ACTION_CALL_ALT)
            addAction(ACTION_AUDIO)
            addAction(ACTION_AG_EVENT)
        }
        registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)

        try {
            val adapter = getSystemService(BluetoothManager::class.java).adapter
            val ok = adapter.getProfileProxy(this, profileListener, PROFILE_HEADSET_CLIENT)
            Log.i(TAG, "getProfileProxy(HEADSET_CLIENT) = $ok")
        } catch (t: SecurityException) {
            Log.e(TAG, "Missing Bluetooth permission", t)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            CMD_ANSWER -> answer()
            CMD_REJECT -> reject()
            CMD_END -> end()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Throwable) {}
        stopRinging()
        teardownAudio()
        try {
            proxyObj?.let {
                getSystemService(BluetoothManager::class.java).adapter
                    .closeProfileProxy(PROFILE_HEADSET_CLIENT, it)
            }
        } catch (_: Throwable) {}
        instance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- public actions

    fun deviceName(): String = try {
        device?.name ?: device?.address ?: "phone"
    } catch (_: SecurityException) {
        "phone"
    }

    fun dial(number: String): Boolean {
        val c = client ?: return false
        val d = device ?: return false
        val ok = c.dial(d, number)
        log("dial -> $ok")
        handler.postDelayed({ refresh() }, 500)
        return ok
    }

    fun answer() {
        val c = client ?: return
        val d = device ?: return
        c.acceptCall(d)
        handler.postDelayed({ refresh() }, 300)
    }

    fun reject() {
        val c = client ?: return
        val d = device ?: return
        c.rejectCall(d)
        handler.postDelayed({ refresh() }, 300)
    }

    fun end() {
        val c = client ?: return
        val d = device ?: return
        val target = calls.firstOrNull { it.isActive || it.isOutgoing }
            ?: calls.firstOrNull { !it.isIncoming }
        c.terminateCall(d, target?.raw)
        handler.postDelayed({ refresh() }, 300)
    }

    fun toggleMute() {
        muted = !muted
        audio.isMicrophoneMute = muted
        notifyChanged()
    }

    fun toggleSpeaker() {
        speakerOn = !speakerOn
        applyRoute()
        notifyChanged()
    }

    /** Tries to open an HFP-client connection to every bonded device. Returns attempts made. */
    fun connectBonded(): Int {
        val c = client ?: return 0
        return try {
            val bonded = getSystemService(BluetoothManager::class.java).adapter.bondedDevices
            bonded.count { c.connect(it) }
        } catch (_: SecurityException) {
            0
        }
    }

    // ---------------------------------------------------------------- state machine

    private fun refresh() {
        val c = client
        if (c == null) {
            device = null
            calls = emptyList()
        } else {
            val d = c.connectedDevices().firstOrNull()
            device = d
            calls = d?.let { c.currentCalls(it).filter { call -> call.state != CallInfo.TERMINATED } }
                ?: emptyList()
        }
        applyCallState()
        notifyChanged()
    }

    private fun applyCallState() {
        val c = client
        val d = device
        val incoming = calls.firstOrNull { it.isIncoming }
        val live = calls.any { it.isActive || it.isOutgoing || it.isHeld }

        updateOngoing()

        if (incoming != null && !live) startRinging() else stopRinging()

        if (incoming != null) showIncomingNotification(incoming) else nm.cancel(NOTIF_CALL)

        if (calls.isNotEmpty()) launchCallUi()

        val mode = audioMode()
        if (live) {
            if (mode >= 2) setupAudio() else teardownAudio()
            val now = System.currentTimeMillis()
            if (mode >= 1 && c != null && d != null &&
                c.audioState(d) != HfpClientProxy.AUDIO_STATE_CONNECTED &&
                now - lastAudioAttempt > 2000
            ) {
                lastAudioAttempt = now
                val ok = c.connectAudio(d)
                log("connectAudio -> $ok")
            }
        } else {
            teardownAudio()
        }
    }

    private fun notifyChanged() {
        listeners.forEach { it.onHfpChanged() }
    }

    // ---------------------------------------------------------------- audio

    private fun setupAudio() {
        if (!audioActive) {
            audio.mode = AudioManager.MODE_IN_COMMUNICATION
            audio.isMicrophoneMute = muted
            audioActive = true
        }
        applyRoute()
    }

    private fun applyRoute() {
        if (!audioActive) return
        try {
            val wanted = if (speakerOn) AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
            else AudioDeviceInfo.TYPE_BUILTIN_EARPIECE
            val target = audio.availableCommunicationDevices.firstOrNull { it.type == wanted }
            if (target != null) audio.setCommunicationDevice(target)
        } catch (t: Throwable) {
            Log.w(TAG, "applyRoute failed", t)
        }
    }

    private fun teardownAudio() {
        if (!audioActive) return
        try { audio.clearCommunicationDevice() } catch (_: Throwable) {}
        audio.isMicrophoneMute = false
        audio.mode = AudioManager.MODE_NORMAL
        audioActive = false
        muted = false
        speakerOn = false
    }

    private fun startRinging() {
        if (ringtone?.isPlaying == true) return
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ringtone = RingtoneManager.getRingtone(this, uri)?.apply {
                audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                isLooping = true
                play()
            }
        } catch (t: Throwable) {
            Log.w(TAG, "ringtone failed", t)
        }
    }

    private fun stopRinging() {
        try { ringtone?.stop() } catch (_: Throwable) {}
        ringtone = null
    }

    // ---------------------------------------------------------------- UI / notifications

    private fun createChannels() {
        nm.createNotificationChannel(
            NotificationChannel(CH_ONGOING, "Headset service", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_CALL, "Calls", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)
            }
        )
    }

    private fun ongoingNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH_ONGOING)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("Bluetooth Headset")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }

    private fun updateOngoing() {
        val text = when {
            client == null -> "Waiting for HFP client profile"
            device == null -> "No phone connected"
            calls.isNotEmpty() -> "${deviceName()} • ${calls.first().label}"
            else -> "Connected to ${deviceName()}"
        }
        nm.notify(NOTIF_ONGOING, ongoingNotification(text))
    }

    private fun callIntent(): Intent = Intent(this, CallActivity::class.java)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)

    private fun launchCallUi() {
        if (CallActivity.visible) return
        if (Settings.canDrawOverlays(this)) {
            try { startActivity(callIntent()) } catch (t: Throwable) { Log.w(TAG, "startActivity failed", t) }
        }
    }

    private fun cmdPending(action: String, code: Int): PendingIntent = PendingIntent.getService(
        this, code, Intent(this, HfpClientService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE
    )

    private fun showIncomingNotification(call: CallInfo) {
        val fullScreen = PendingIntent.getActivity(this, 10, callIntent(), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH_CALL)
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle("Incoming call")
            .setContentText(call.number.ifBlank { "Unknown caller" })
            .setCategory(Notification.CATEGORY_CALL)
            .setOngoing(true)
            .setFullScreenIntent(fullScreen, true)
            .setContentIntent(fullScreen)
            .addAction(Notification.Action.Builder(null, "Answer", cmdPending(CMD_ANSWER, 11)).build())
            .addAction(Notification.Action.Builder(null, "Decline", cmdPending(CMD_REJECT, 12)).build())
            .build()
        nm.notify(NOTIF_CALL, n)
    }
}
