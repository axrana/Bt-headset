package com.axrana.btheadset

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class CallActivity : Activity(), HfpClientService.Listener {

    companion object {
        @Volatile var visible = false
    }

    private lateinit var tvState: TextView
    private lateinit var tvNumber: TextView
    private lateinit var rowIncoming: LinearLayout
    private lateinit var rowControls: LinearLayout
    private lateinit var btnMute: Button
    private lateinit var btnSpeaker: Button
    private lateinit var btnEnd: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setBackgroundColor(color)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(0, dp(64), 1f).apply {
            setMargins(dp(6), dp(6), dp(6), dp(6))
        }
    }

    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(48), dp(24), dp(48))
            setBackgroundColor(Color.parseColor("#101418"))
        }

        tvState = TextView(this).apply {
            textSize = 18f
            setTextColor(Color.parseColor("#9AA5B1"))
            gravity = Gravity.CENTER
        }
        tvNumber = TextView(this).apply {
            textSize = 34f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(48))
        }
        root.addView(tvState)
        root.addView(tvNumber)

        rowIncoming = row().apply {
            addView(button("Answer", Color.parseColor("#2E7D32")) { HfpClientService.instance?.answer() })
            addView(button("Reject", Color.parseColor("#C62828")) { HfpClientService.instance?.reject() })
        }
        root.addView(rowIncoming)

        rowControls = row().apply {
            btnMute = button("Mute", Color.parseColor("#37474F")) { HfpClientService.instance?.toggleMute() }
            btnSpeaker = button("Speaker", Color.parseColor("#37474F")) { HfpClientService.instance?.toggleSpeaker() }
            addView(btnMute)
            addView(btnSpeaker)
        }
        root.addView(rowControls)

        btnEnd = button("End call", Color.parseColor("#C62828")) { HfpClientService.instance?.end() }
        val endRow = row().apply { addView(btnEnd) }
        root.addView(endRow)

        setContentView(root)
    }

    override fun onStart() {
        super.onStart()
        visible = true
        HfpClientService.listeners.add(this)
        update()
    }

    override fun onStop() {
        HfpClientService.listeners.remove(this)
        visible = false
        super.onStop()
    }

    override fun onHfpChanged() {
        runOnUiThread { update() }
    }

    private fun update() {
        val s = HfpClientService.instance
        val calls = s?.calls.orEmpty()
        if (s == null || calls.isEmpty()) {
            finish()
            return
        }
        val primary = calls.firstOrNull { it.isIncoming } ?: calls.first()
        tvNumber.text = primary.number.ifBlank { "Unknown caller" }
        tvState.text = primary.label

        val incoming = primary.isIncoming
        rowIncoming.visibility = if (incoming) View.VISIBLE else View.GONE
        rowControls.visibility = if (incoming) View.GONE else View.VISIBLE
        btnEnd.visibility = if (incoming) View.GONE else View.VISIBLE
        btnMute.text = if (s.muted) "Unmute" else "Mute"
        btnSpeaker.text = if (s.speakerOn) "Earpiece" else "Speaker"
    }
}
