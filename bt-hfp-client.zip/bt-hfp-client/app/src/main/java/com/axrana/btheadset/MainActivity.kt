package com.axrana.btheadset

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), HfpClientService.Listener {

    private lateinit var tvStatus: TextView
    private lateinit var etNumber: EditText
    private lateinit var btnAudio: Button
    private lateinit var tvLog: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun hasBt() =
        checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun padButton(label: String, onClick: () -> Unit, onLong: (() -> Boolean)? = null) =
        Button(this).apply {
            text = label
            textSize = 22f
            setOnClickListener { onClick() }
            if (onLong != null) setOnLongClickListener { onLong() }
            layoutParams = LinearLayout.LayoutParams(0, dp(64), 1f).apply {
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(16))
        }

        tvStatus = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.parseColor("#9AA5B1"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(12))
        }
        root.addView(tvStatus)

        etNumber = EditText(this).apply {
            hint = "Number to dial on the OnePlus"
            textSize = 26f
            gravity = Gravity.CENTER
            inputType = InputType.TYPE_CLASS_PHONE
        }
        root.addView(etNumber)

        val keys = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("*", "0", "#")
        )
        for (keyRow in keys) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in keyRow) {
                row.addView(
                    padButton(
                        k,
                        { etNumber.append(k) },
                        if (k == "0") ({ etNumber.append("+"); true }) else null
                    )
                )
            }
            root.addView(row)
        }

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(padButton("⌫", {
            val t = etNumber.text
            if (t.isNotEmpty()) t.delete(t.length - 1, t.length)
        }))
        actions.addView(padButton("Call", { dial() }))
        root.addView(actions)

        root.addView(Button(this).apply {
            text = "Connect to paired phone"
            setOnClickListener { connectBonded() }
        })
        root.addView(Button(this).apply {
            text = "Grant permissions"
            setOnClickListener { ensurePermissions() }
        })

        btnAudio = Button(this).apply {
            text = "Audio mode"
            setOnClickListener { HfpClientService.instance?.cycleAudioMode() }
        }
        root.addView(btnAudio)

        root.addView(Button(this).apply {
            text = "Save log to Downloads"
            setOnClickListener { saveLog() }
        })

        tvLog = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.parseColor("#9AA5B1"))
            setPadding(0, dp(12), 0, 0)
        }
        root.addView(tvLog)

        setContentView(ScrollView(this).apply { addView(root) })
        ensurePermissions()
    }

    override fun onResume() {
        super.onResume()
        HfpClientService.listeners.add(this)
        if (hasBt()) HfpClientService.start(this)
        updateStatus()
    }

    override fun onPause() {
        HfpClientService.listeners.remove(this)
        super.onPause()
    }

    override fun onHfpChanged() {
        runOnUiThread { updateStatus() }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (hasBt()) HfpClientService.start(this)
        ensurePermissions()
    }

    private fun ensurePermissions() {
        val needed = arrayOf(
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.POST_NOTIFICATIONS
        ).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }

        if (needed.isNotEmpty()) {
            requestPermissions(needed.toTypedArray(), 1)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
    }

    private fun dial() {
        val number = etNumber.text.toString().trim()
        if (number.isEmpty()) return
        val s = HfpClientService.instance
        if (s == null || !s.dial(number)) {
            Toast.makeText(this, "Dial failed — is the phone connected over HFP?", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveLog() {
        val appLog = HfpClientService.instance?.logText().orEmpty()
        Thread {
            val msg = try {
                val name = "hfp_log_" + System.currentTimeMillis() + ".txt"
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, "Download")
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("could not create file")
                val proc = Runtime.getRuntime().exec(arrayOf("logcat", "-d", "-v", "threadtime"))
                contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(("APP LOG:\n" + appLog + "\n\nSYSTEM LOG:\n").toByteArray())
                    proc.inputStream.copyTo(out)
                }
                "Saved Downloads/$name"
            } catch (t: Throwable) {
                "Save failed: " + t.message
            }
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        }.start()
    }

    private fun connectBonded() {
        val n = HfpClientService.instance?.connectBonded() ?: 0
        Toast.makeText(this, "Connection requested for $n device(s)", Toast.LENGTH_SHORT).show()
    }

    private fun updateStatus() {
        val s = HfpClientService.instance
        tvStatus.text = when {
            s == null -> "Service not running"
            s.client == null -> "Waiting for HFP client profile…\n(is the Magisk module active and the phone rebooted?)"
            s.device == null -> "HFP client ready — no phone connected"
            else -> "Connected: ${s.deviceName()}"
        }
        btnAudio.text = "Audio mode: " + (s?.audioModeName() ?: "-")
        tvLog.text = s?.logText().orEmpty()
    }
}
