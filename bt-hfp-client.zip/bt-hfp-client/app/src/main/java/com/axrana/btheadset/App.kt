package com.axrana.btheadset

import android.app.Application
import android.util.Log
import org.lsposed.hiddenapibypass.HiddenApiBypass

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            // Exempt every hidden API signature so reflection on BluetoothHeadsetClient works.
            HiddenApiBypass.addHiddenApiExemptions("L")
        } catch (t: Throwable) {
            Log.w("BtHeadset", "Hidden API bypass failed", t)
        }
    }
}
