package com.axrana.btheadset

import android.bluetooth.BluetoothDevice
import android.util.Log
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Method

data class CallInfo(val id: Int, val number: String, val state: Int, val raw: Any) {
    val isIncoming: Boolean get() = state == INCOMING || state == WAITING
    val isOutgoing: Boolean get() = state == DIALING || state == ALERTING
    val isActive: Boolean get() = state == ACTIVE
    val isHeld: Boolean get() = state == HELD || state == HELD_BY_RESPONSE_AND_HOLD

    val label: String
        get() = when (state) {
            ACTIVE -> "Ongoing call"
            HELD, HELD_BY_RESPONSE_AND_HOLD -> "On hold"
            DIALING -> "Dialing…"
            ALERTING -> "Ringing…"
            INCOMING -> "Incoming call"
            WAITING -> "Call waiting"
            else -> "Call ended"
        }

    companion object {
        const val ACTIVE = 0
        const val HELD = 1
        const val DIALING = 2
        const val ALERTING = 3
        const val INCOMING = 4
        const val WAITING = 5
        const val HELD_BY_RESPONSE_AND_HOLD = 6
        const val TERMINATED = 7
    }
}

/** Reflection wrapper around the hidden android.bluetooth.BluetoothHeadsetClient (profile 16). */
class HfpClientProxy(private val proxy: Any) {

    private val clientClass: Class<*> = Class.forName("android.bluetooth.BluetoothHeadsetClient")
    private val callClass: Class<*> = Class.forName("android.bluetooth.BluetoothHeadsetClientCall")

    private fun find(name: String, argc: Int): Method? =
        clientClass.methods.firstOrNull { it.name == name && it.parameterTypes.size == argc }

    private fun call(name: String, vararg args: Any?): Any? {
        val m = find(name, args.size)
        if (m == null) {
            Log.w(TAG, "Method not found: $name/${args.size}")
            return null
        }
        return try {
            m.invoke(proxy, *args)
        } catch (e: InvocationTargetException) {
            Log.e(TAG, "$name failed", e.targetException)
            null
        } catch (t: Throwable) {
            Log.e(TAG, "$name failed", t)
            null
        }
    }

    @Suppress("UNCHECKED_CAST")
    fun connectedDevices(): List<BluetoothDevice> =
        (call("getConnectedDevices") as? List<BluetoothDevice>) ?: emptyList()

    fun currentCalls(device: BluetoothDevice): List<CallInfo> {
        val list = call("getCurrentCalls", device) as? List<*> ?: return emptyList()
        return list.filterNotNull().mapNotNull { toInfo(it) }
    }

    private fun toInfo(raw: Any): CallInfo? = try {
        CallInfo(
            id = callClass.getMethod("getId").invoke(raw) as Int,
            number = (callClass.getMethod("getNumber").invoke(raw) as? String).orEmpty(),
            state = callClass.getMethod("getState").invoke(raw) as Int,
            raw = raw
        )
    } catch (t: Throwable) {
        Log.e(TAG, "Failed to read call", t)
        null
    }

    fun connect(device: BluetoothDevice): Boolean = (call("connect", device) as? Boolean) ?: false

    fun dial(device: BluetoothDevice, number: String): Boolean = call("dial", device, number) != null

    fun acceptCall(device: BluetoothDevice): Boolean =
        (call("acceptCall", device, CALL_ACCEPT_NONE) as? Boolean) ?: false

    fun rejectCall(device: BluetoothDevice): Boolean = (call("rejectCall", device) as? Boolean) ?: false

    /** [rawCall] null terminates all calls. */
    fun terminateCall(device: BluetoothDevice, rawCall: Any?): Boolean =
        (call("terminateCall", device, rawCall) as? Boolean) ?: false

    fun connectAudio(device: BluetoothDevice): Boolean = (call("connectAudio", device) as? Boolean) ?: false

    fun disconnectAudio(device: BluetoothDevice): Boolean =
        (call("disconnectAudio", device) as? Boolean) ?: false

    fun audioState(device: BluetoothDevice): Int = (call("getAudioState", device) as? Int) ?: 0

    companion object {
        private const val TAG = "HfpClientProxy"
        const val CALL_ACCEPT_NONE = 0
        const val AUDIO_STATE_CONNECTED = 2
    }
}
